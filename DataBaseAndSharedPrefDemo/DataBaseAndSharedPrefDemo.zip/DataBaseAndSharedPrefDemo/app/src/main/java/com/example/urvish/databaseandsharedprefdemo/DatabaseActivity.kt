package com.example.urvish.databaseandsharedprefdemo

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_database.*;

class DatabaseActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_database)
        val user = MainActivity.userDataBase.userDao().getAll() as ArrayList<User>
        val userAdapter=UserAdapter(this,user)
        listview.adapter=userAdapter
    }
}
