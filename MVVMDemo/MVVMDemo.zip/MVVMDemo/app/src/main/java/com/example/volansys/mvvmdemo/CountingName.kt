package com.example.volansys.mvvmdemo

object CountingName {
    fun getCount(name: String): Int {
        return name.length
    }
}
