package com.example.volansys.mvvmdemo

import android.databinding.DataBindingUtil
import android.support.v7.app.AppCompatActivity
import android.os.Bundle


class ProfileActivity : AppCompatActivity() {
    private var profileBinding: PhotoBinder? = null
    private var profileViewModel: ProfileViewModel? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        profileBinding = DataBindingUtil.setContentView(this, R.layout.activity_profile)
        val i = intent
        profileViewModel = ProfileViewModel(this, i)
        profileBinding!!.photoData = profileViewModel


    }
}
