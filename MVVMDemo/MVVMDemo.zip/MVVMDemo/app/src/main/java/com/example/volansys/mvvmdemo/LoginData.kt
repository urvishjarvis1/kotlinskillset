package com.example.volansys.mvvmdemo


class LoginData {
    var email: String? = null
    var password: String? = null
    var imgUrl: String? = null
}
