package com.example.volansys.mvvmdemo

import android.app.Activity
import android.databinding.DataBindingUtil
import android.support.v7.app.AppCompatActivity
import android.os.Bundle


class MainActivity : AppCompatActivity() {
    private var activity: Activity? = null
    private var binding: ActivityMainBinding? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        activity = this
        val mainViewModel = MainViewModel(this)
        binding!!.loginData = mainViewModel
        val handlers = MyClickHandlers(this)
        binding!!.handlers = handlers

    }

}
